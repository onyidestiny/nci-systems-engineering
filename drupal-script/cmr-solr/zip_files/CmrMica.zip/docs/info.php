<?php
print 'Hi there';
?>